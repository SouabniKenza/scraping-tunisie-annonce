import os
import json

json_dir = "D:/Cours/Polytech/IRM2/S2/python/Projet-Kenza Souabni BDAI/v2/PART2/Figures"

for filename in os.listdir(json_dir):
    if filename.endswith(".json"):
        path = os.path.join(json_dir, filename)
        with open(path, "r", encoding="utf-8") as f:
            content = f.read()

        if "heatmapgl" in content:
            print(f"🔁 Remplacement dans : {filename}")
            new_content = content.replace("heatmapgl", "heatmap")

            with open(path, "w", encoding="utf-8") as f:
                f.write(new_content)
        else:
            print(f"✅ Aucun problème dans : {filename}")
