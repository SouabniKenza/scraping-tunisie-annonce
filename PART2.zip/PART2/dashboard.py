import dash
from dash import html, dcc
import plotly.io as pio
import os

# 📁 Chemin vers les figures
base_path = "D:/Cours/Polytech/IRM2/S2/python/Projet-Kenza Souabni BDAI/v2/PART2/Figures"

def load_figure(filename):
    path = os.path.join(base_path, filename)
    return pio.from_json(open(path, "r", encoding="utf-8").read())

# ✅ Chargement des figures dans un dictionnaire
des_figures = [
    "fig_rep_prix", "fig_rep_surface", "fig_rep_prix_m", "fig_constructible",
    "fig_meuble", "fig_annonces_par_ville", "fig_plage_par_region",
    "fig_nbannmois", "fig_surf_moy_mois", "fig_prix_moy_m_mois", "fig_bien_plage_mois",
    "fig_rep_nature", "fig_prix_m2_type", "fig_surface_moyenne_type",
    "fig_prix_moyen_region", "fig_taux_tel_region", "fig_rep_hierarchique", "figsurface_prix"
]

figures = {}
for name in des_figures:
    try:
        figures[name] = load_figure(name + ".json")
    except Exception as e:
        print(f"Erreur lors du chargement de {name} : {e}")

# 🚀 Initialisation de l'app
app = dash.Dash(__name__)
app.title = "Tableau de bord immobilier"

# 🎨 Mise en page style BI (2 colonnes)
def two_col_layout(fig_left, fig_right):
    return html.Div([
        html.Div(dcc.Graph(figure=figures[fig_left]), style={"width": "48%", "display": "inline-block", "padding": "0 10px"}),
        html.Div(dcc.Graph(figure=figures[fig_right]), style={"width": "48%", "display": "inline-block", "padding": "0 10px"}),
    ])

# 📅 Layout principal avec onglets + disposition propre
tabs_layout = dcc.Tabs([
    dcc.Tab(label="🔖 Statistiques de base", children=[
        two_col_layout("fig_rep_prix", "fig_rep_surface"),
        two_col_layout("fig_rep_prix_m", "figsurface_prix"),
    ]),

    dcc.Tab(label="🧠 Profil du marché", children=[
        two_col_layout("fig_constructible", "fig_meuble"),
        two_col_layout("fig_rep_nature", "fig_rep_hierarchique"),
    ]),

    dcc.Tab(label="🏛️ Analyse géographique", children=[
        two_col_layout("fig_annonces_par_ville", "fig_plage_par_region"),
        two_col_layout("fig_prix_moyen_region", "fig_taux_tel_region"),
    ]),

    dcc.Tab(label="🗓️ Analyse temporelle", children=[
        two_col_layout("fig_nbannmois", "fig_surf_moy_mois"),
        two_col_layout("fig_prix_moy_m_mois", "fig_bien_plage_mois"),
    ])
])

# 🌐 App Layout final
app.layout = html.Div([
    html.H1("📊 Tableau de bord des annonces immobilières", style={"textAlign": "center"}),
    tabs_layout
], style={"padding": "20px", "fontFamily": "Arial"})

# ▶️ Run Server
if __name__ == '__main__':
    app.run(debug=True)

#http://127.0.0.1:8050/

import dash
from dash import html, dcc, Input, Output
import plotly.io as pio
import os

# 📁 Chemin vers les figures JSON
base_path = "D:/Cours/Polytech/IRM2/S2/python/Projet-Kenza Souabni BDAI/v2/PART2/Figures"

def load_figure(filename):
    path = os.path.join(base_path, filename)
    return pio.from_json(open(path, "r", encoding="utf-8").read())

# ✅ Chargement des figures
figures = {
    "Prix": load_figure("fig_rep_prix.json"),
    "Surface": load_figure("fig_rep_surface.json"),
    "Prix_m2": load_figure("fig_rep_prix_m.json"),
    "Constructible": load_figure("fig_constructible.json"),
    "Meublé": load_figure("fig_meuble.json"),
    "Villes": load_figure("fig_annonces_par_ville.json"),
    "Plage": load_figure("fig_plage_par_region.json"),
    "Annonces_mois": load_figure("fig_nbannmois.json"),
    "Surf_mois": load_figure("fig_surf_moy_mois.json"),
    "Prix_mois": load_figure("fig_prix_moy_m_mois.json"),
    "Plage_mois": load_figure("fig_bien_plage_mois.json"),
    "Nature": load_figure("fig_rep_nature.json"),
    "Prix_type": load_figure("fig_prix_m2_type.json"),
    "Surf_type": load_figure("fig_surface_moyenne_type.json"),
    "Prix_region": load_figure("fig_prix_moyen_region.json"),
    "Tel_region": load_figure("fig_taux_tel_region.json"),
    "Hierarchie": load_figure("fig_rep_hierarchique.json"),
    "Surface_Prix": load_figure("figsurface_prix.json")
}

# 🚀 Initialisation Dash
app = dash.Dash(__name__)
app.title = "Dashboard Immobilier"

# 🖼️ Layout avec filtre dropdown et grilles de graphiques
app.layout = html.Div([
    html.H1("📊 Dashboard des annonces immobilières", style={"textAlign": "center"}),

    html.Div([
        html.Label("Choisir un type de graphique à afficher :"),
        dcc.Dropdown(
            id="figure-selector",
            options=[{"label": k.replace("_", " "), "value": k} for k in figures.keys()],
            value="Prix",
            clearable=False
        )
    ], style={"width": "50%", "margin": "0 auto 30px"}),

    html.Div(id="graph-output")
])

# 🔁 Callback interactif
@app.callback(
    Output("graph-output", "children"),
    Input("figure-selector", "value")
)
def update_graph(selected):
    return dcc.Graph(figure=figures[selected])

# ▶️ Run
if __name__ == '__main__':
    app.run(debug=True)
